# 日本株スクリーナー Web版

スマホ/PCブラウザで使える FastAPI + HTML/JavaScript のWebアプリです。

## 主な機能
- 従業員1人当たり売上高
- 有利子負債
- 決算発表後の翌営業日騰落統計
- 会社名/証券コード検索
- 1人当たり売上高・有利子負債・決算翌日上昇率で絞り込み
- 列クリックでランキング並べ替え
- 銘柄ごとの決算反応履歴
- 結果CSVダウンロード
- APIキーなしでUI確認できるデモモード
- iPhone対応レスポンシブUI

## ローカル起動
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn main:app --reload
```
ブラウザで `http://127.0.0.1:8000` を開きます。

## 公開URLにする
Dockerfile と render.yaml を同梱しています。GitHubへ置いてRender等のDocker対応ホスティングに接続すれば公開できます。

## J-Quants
V2 API (`https://api.jquants.com/v2`) を利用します。認証は入力されたAPIキーを `x-api-key` ヘッダーとしてJ-Quantsに送ります。アプリ側には永続保存しません。

利用エンドポイント:
- `/fins/summary`
- `/equities/bars/daily`
- `/fins/details`（有利子負債自動抽出。利用可能プランのみ）

## 従業員数CSV
`sample_overrides.csv` を参照してください。

必須:
- `code`
- `employees`

任意:
- `revenue`（円）
- `interest_bearing_debt`（円）

## 決算翌日騰落率の定義
決算発表日までの最新終値から、発表後最初の営業日の終値への騰落率です。場中発表を時刻単位で厳密に評価する場合は分足データを使う拡張が必要です。

## 注意
`/api/demo` の値はUI確認用サンプルで、投資判断には利用できません。
